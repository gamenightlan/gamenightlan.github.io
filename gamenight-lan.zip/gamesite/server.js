/**
 * GameNight LAN Server
 * --------------------
 * Run this on ONE computer on your WiFi.
 * Everyone else opens a browser and goes to http://YOUR_IP:3000
 *
 * Start:  node server.js
 * Stop:   Ctrl+C
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Try to load socket.io (optional, falls back to polling) ──
let io = null;
try {
  const { Server } = require('socket.io');
  const httpServer = http.createServer(serveFile);
  io = new Server(httpServer, { cors: { origin: '*' } });
  setupSocketHandlers(io);
  const PORT = process.env.PORT || 3000;
  httpServer.listen(PORT, '0.0.0.0', () => printBanner(PORT));
} catch (e) {
  // socket.io not installed — use built-in polling fallback
  console.log('socket.io not found — using built-in polling mode (still works!)');
  console.log('For better performance run:  npm install socket.io\n');
  const server = http.createServer(handleRequest);
  const PORT = process.env.PORT || 3000;
  server.listen(PORT, '0.0.0.0', () => printBanner(PORT));
}

// ── Get local IP ──────────────────────────────────────────────
function getLocalIP() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return 'localhost';
}

function printBanner(PORT) {
  const ip = getLocalIP();
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║        🎮  GameNight LAN Server           ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  Your link:  http://${ip}:${PORT}        `);
  console.log(`║  Local:      http://localhost:${PORT}         `);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  Share the link above with anyone on     ║');
  console.log('║  the same WiFi — they can play instantly! ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  Press Ctrl+C to stop the server          ║');
  console.log('╚══════════════════════════════════════════╝\n');
}

// ── Static file server ────────────────────────────────────────
const MIME = {
  '.html': 'text/html', '.js': 'application/javascript',
  '.css': 'text/css', '.json': 'application/json',
  '.png': 'image/png', '.ico': 'image/x-icon',
};

function serveFile(req, res) {
  // API routes handled separately
  if (req.url.startsWith('/api/')) return;

  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
  // strip query string
  filePath = filePath.split('?')[0];

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404); res.end('Not found');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'text/plain',
      'Access-Control-Allow-Origin': '*',
    });
    res.end(data);
  });
}

// ── Polling fallback (no socket.io) ───────────────────────────
const rooms = {}; // roomId → { game, state, players, chat, updated }

function handleRequest(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  const url = new URL(req.url, 'http://localhost');

  // ── Serve static files ──
  if (!url.pathname.startsWith('/api/')) {
    return serveFile(req, res);
  }

  // ── API: GET /api/room/:id ──
  if (req.method === 'GET' && url.pathname.startsWith('/api/room/')) {
    const roomId = url.pathname.split('/')[3];
    const since = parseInt(url.searchParams.get('since') || '0');
    const room = rooms[roomId];
    if (!room) { json(res, { error: 'Room not found' }, 404); return; }
    // Only send if updated since last poll
    if (room.updated > since) {
      json(res, { ...room, ok: true });
    } else {
      json(res, { ok: true, unchanged: true });
    }
    return;
  }

  // ── API: POST /api/room/:id ──
  if (req.method === 'POST' && url.pathname.startsWith('/api/room/')) {
    const roomId = url.pathname.split('/')[3];
    let body = '';
    req.on('data', d => body += d);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        if (data.action === 'create') {
          rooms[roomId] = {
            id: roomId, game: data.game,
            state: data.state || {},
            players: [{ name: data.playerName, id: data.playerId, joinedAt: Date.now() }],
            chat: [],
            updated: Date.now(),
          };
          json(res, { ok: true, room: rooms[roomId] });
        } else if (data.action === 'join') {
          if (!rooms[roomId]) { json(res, { error: 'Room not found' }, 404); return; }
          const already = rooms[roomId].players.find(p => p.id === data.playerId);
          if (!already) rooms[roomId].players.push({ name: data.playerName, id: data.playerId, joinedAt: Date.now() });
          rooms[roomId].updated = Date.now();
          json(res, { ok: true, room: rooms[roomId] });
        } else if (data.action === 'state') {
          if (!rooms[roomId]) { json(res, { error: 'Room not found' }, 404); return; }
          rooms[roomId].state = data.state;
          rooms[roomId].updated = Date.now();
          json(res, { ok: true });
        } else if (data.action === 'chat') {
          if (!rooms[roomId]) { json(res, { error: 'Room not found' }, 404); return; }
          rooms[roomId].chat.push({ name: data.playerName, msg: data.msg, t: Date.now() });
          if (rooms[roomId].chat.length > 50) rooms[roomId].chat.shift();
          rooms[roomId].updated = Date.now();
          json(res, { ok: true });
        } else {
          json(res, { error: 'Unknown action' }, 400);
        }
      } catch (e) { json(res, { error: 'Bad JSON' }, 400); }
    });
    return;
  }

  // ── API: GET /api/rooms (list active rooms) ──
  if (req.method === 'GET' && url.pathname === '/api/rooms') {
    const list = Object.values(rooms).map(r => ({
      id: r.id, game: r.game,
      players: r.players.length,
      updated: r.updated,
    }));
    json(res, { rooms: list });
    return;
  }

  res.writeHead(404); res.end('Not found');
}

function json(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

// ── Socket.io handlers (used when socket.io is installed) ─────
function setupSocketHandlers(io) {
  io.on('connection', (socket) => {
    let myRoom = null;

    socket.on('create-room', ({ roomId, game, playerName, playerId }) => {
      rooms[roomId] = {
        id: roomId, game,
        state: {},
        players: [{ name: playerName, id: playerId }],
        chat: [],
        updated: Date.now(),
      };
      myRoom = roomId;
      socket.join(roomId);
      io.to(roomId).emit('room-update', rooms[roomId]);
    });

    socket.on('join-room', ({ roomId, playerName, playerId }) => {
      if (!rooms[roomId]) { socket.emit('error', 'Room not found'); return; }
      const already = rooms[roomId].players.find(p => p.id === playerId);
      if (!already) rooms[roomId].players.push({ name: playerName, id: playerId });
      rooms[roomId].updated = Date.now();
      myRoom = roomId;
      socket.join(roomId);
      io.to(roomId).emit('room-update', rooms[roomId]);
    });

    socket.on('game-state', ({ roomId, state }) => {
      if (!rooms[roomId]) return;
      rooms[roomId].state = state;
      rooms[roomId].updated = Date.now();
      socket.to(roomId).emit('game-state', state);
    });

    socket.on('chat', ({ roomId, playerName, msg }) => {
      if (!rooms[roomId]) return;
      const entry = { name: playerName, msg, t: Date.now() };
      rooms[roomId].chat.push(entry);
      if (rooms[roomId].chat.length > 50) rooms[roomId].chat.shift();
      rooms[roomId].updated = Date.now();
      io.to(roomId).emit('chat', entry);
    });

    socket.on('disconnect', () => {
      if (myRoom && rooms[myRoom]) {
        // keep room alive for 5 min after disconnect
        setTimeout(() => { if (rooms[myRoom]) delete rooms[myRoom]; }, 5 * 60 * 1000);
      }
    });
  });
}
