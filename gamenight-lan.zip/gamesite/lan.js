/**
 * GameNight LAN Client
 * Works with socket.io (fast) OR plain HTTP polling (fallback).
 * Games just call: LAN.create(), LAN.join(), LAN.send(), LAN.onState()
 */
window.LAN = (() => {
  let _socket = null;
  let _polling = false;
  let _roomId = null;
  let _playerName = null;
  let _playerId = null;
  let _lastUpdated = 0;
  let _pollInterval = null;
  let _handlers = {};
  let _isConnected = false;

  // Generate a random player ID stored in sessionStorage
  function getPlayerId() {
    let id = sessionStorage.getItem('gn_player_id');
    if (!id) { id = Math.random().toString(36).slice(2, 10); sessionStorage.setItem('gn_player_id', id); }
    return id;
  }

  function generateRoomCode() {
    return Array.from({ length: 6 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
  }

  // Try socket.io first, fall back to polling
  async function connect() {
    return new Promise(resolve => {
      if (typeof io !== 'undefined') {
        try {
          _socket = io();
          _socket.on('connect', () => { _isConnected = true; _polling = false; resolve('socket'); });
          _socket.on('connect_error', () => { _socket = null; _polling = true; _isConnected = true; resolve('polling'); });
          _socket.on('room-update', data => trigger('room-update', data));
          _socket.on('game-state', data => trigger('state', data));
          _socket.on('chat', data => trigger('chat', data));
          _socket.on('error', err => trigger('error', err));
          setTimeout(() => { if (!_isConnected) { _polling = true; _isConnected = true; resolve('polling'); } }, 1500);
        } catch (e) { _polling = true; _isConnected = true; resolve('polling'); }
      } else {
        _polling = true; _isConnected = true; resolve('polling');
      }
    });
  }

  function trigger(event, data) {
    if (_handlers[event]) _handlers[event].forEach(fn => fn(data));
  }

  async function apiPost(path, body) {
    const res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return res.json();
  }

  async function apiGet(path) {
    const res = await fetch(path);
    return res.json();
  }

  function startPolling() {
    if (_pollInterval) clearInterval(_pollInterval);
    _pollInterval = setInterval(async () => {
      if (!_roomId || !_polling) return;
      try {
        const data = await apiGet(`/api/room/${_roomId}?since=${_lastUpdated}`);
        if (data.ok && !data.unchanged) {
          _lastUpdated = data.updated || Date.now();
          trigger('room-update', data);
          if (data.state) trigger('state', data.state);
        }
      } catch (e) { /* network hiccup, retry next poll */ }
    }, 400); // poll every 400ms — fast enough to feel real-time
  }

  // ── Public API ──────────────────────────────────────────────

  async function init(playerName) {
    _playerName = playerName || 'Player';
    _playerId = getPlayerId();
    const mode = await connect();
    console.log(`LAN: connected via ${mode}`);
    return mode;
  }

  async function create(game) {
    _roomId = generateRoomCode();
    if (_polling) {
      await apiPost(`/api/room/${_roomId}`, { action: 'create', game, playerName: _playerName, playerId: _playerId });
      startPolling();
    } else {
      _socket.emit('create-room', { roomId: _roomId, game, playerName: _playerName, playerId: _playerId });
    }
    return _roomId;
  }

  async function join(roomId) {
    _roomId = roomId.toUpperCase();
    if (_polling) {
      const data = await apiPost(`/api/room/${_roomId}`, { action: 'join', playerName: _playerName, playerId: _playerId });
      if (data.error) throw new Error(data.error);
      startPolling();
      return data.room;
    } else {
      return new Promise((resolve, reject) => {
        _socket.emit('join-room', { roomId: _roomId, playerName: _playerName, playerId: _playerId });
        _socket.once('room-update', resolve);
        _socket.once('error', reject);
      });
    }
  }

  async function sendState(state) {
    if (_polling) {
      await apiPost(`/api/room/${_roomId}`, { action: 'state', state, playerId: _playerId });
    } else {
      _socket.emit('game-state', { roomId: _roomId, state });
    }
  }

  async function sendChat(msg) {
    if (_polling) {
      await apiPost(`/api/room/${_roomId}`, { action: 'chat', msg, playerName: _playerName, playerId: _playerId });
    } else {
      _socket.emit('chat', { roomId: _roomId, playerName: _playerName, msg });
    }
  }

  function on(event, fn) {
    if (!_handlers[event]) _handlers[event] = [];
    _handlers[event].push(fn);
  }

  function off(event, fn) {
    if (!_handlers[event]) return;
    _handlers[event] = _handlers[event].filter(f => f !== fn);
  }

  function getPlayerId_() { return _playerId; }
  function getRoomId() { return _roomId; }
  function getPlayerName() { return _playerName; }
  function isPolling() { return _polling; }

  return { init, create, join, sendState, sendChat, on, off, generateRoomCode, getPlayerId: getPlayerId_, getRoomId, getPlayerName, isPolling };
})();
