# 🎮 GameNight — LAN Multiplayer

Play with anyone on the same WiFi. No internet. No accounts. No Firebase.

---

## ▶️ Start Playing (2 steps)

### Step 1 — Start the server

**You need Node.js installed.** Download free at: https://nodejs.org (click the LTS button)

Then open a terminal in this folder and run:

```
node server.js
```

You'll see something like:

```
╔══════════════════════════════════════════╗
║        🎮  GameNight LAN Server           ║
╠══════════════════════════════════════════╣
║  Your link:  http://192.168.1.42:3000    ║
║  Local:      http://localhost:3000       ║
╚══════════════════════════════════════════╝
```

### Step 2 — Everyone opens the link

- **You** open: http://localhost:3000
- **Friends on same WiFi** open: http://192.168.1.XX:3000 (the IP shown in your terminal)

That's it! Create a room, share the code, play.

---

## 💡 Optional: Faster multiplayer with socket.io

The server works without any install. For faster sync, run once:

```
npm install
```

Then `node server.js` as usual. You'll see "socket.io mode" instead of "polling mode".

---

## 🎮 Games included

| Game | Players |
|---|---|
| ♟️ Chess | 2 |
| ⭕ Tic-Tac-Toe | 2 |
| 🃏 Uno | 2–4 |
| 🚢 Battleship | 2 |
| 🔤 Word Scramble | 2–4 |
| ✊ RPS Royale | 2–4 |

---

## ❓ Troubleshooting

**Friends can't connect?**
- Make sure you're all on the same WiFi network
- Try turning off Windows Firewall temporarily, or allow Node.js through it
- Use the IP address shown in the terminal (not localhost)

**"node is not recognized"?**
- Download Node.js from https://nodejs.org and restart your terminal

**Port already in use?**
- Run `node server.js` with a different port: `PORT=4000 node server.js`
- Friends use http://YOUR_IP:4000
